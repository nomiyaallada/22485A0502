const byProductID = async (req, res) => {

}

module.exports = byProductID;