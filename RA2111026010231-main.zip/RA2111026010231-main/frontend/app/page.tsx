import { AllProducts } from "@/components/AllProducts";

export default function Home() {
  return (
    <>
      <AllProducts  />
    </>
  );
}
