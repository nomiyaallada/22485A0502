# RA2111026010231
AFFORDMED Campus Hiring Evaluation - Full Stack


### WEBSITE LINK :  https://gomartt.vercel.app/

## FULL STACK Task 
### CLIENT Screenshots : 

### NEW WEBSITE 
#### HomePage
![Home](/Screenshots/NEW/1.png)

#### Pagination
![Home](/Screenshots/NEW/2.png)

#### Product Page Based On productId
![Home](/Screenshots/NEW/3.png)

#### Demo Cart Page
![Home](/Screenshots/NEW/4.png)


### OLD Test-Website

#### Shorted Product details according to fields
![Filter](/Screenshots/C/Home.png)

#### HomePage
![HomePage](/Screenshots/C/1.png)
#### Filter By Categories
![Filter](/Screenshots/C/2.png)
#### Filter By Company
![Filter](/Screenshots/C/3.png)
#### Sort By Price,Rateint etc.
![Filter](/Screenshots/C/4.png)




### Backend Screenshots : 

#### shortBy RATINGS
![By](/Screenshots/B/1.png)

#### shortBy RATINGS on category PHONES
![By](/Screenshots/B/2.png)

