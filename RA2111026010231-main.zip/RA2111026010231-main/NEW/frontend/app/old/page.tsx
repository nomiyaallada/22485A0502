
import OldAllProducts from '../../components/OldAllProducts'

const OldWebsite = () => {
  return (
    <>
        <OldAllProducts />
    </>
  )
}

export default OldWebsite